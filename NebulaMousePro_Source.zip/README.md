# Nebula Mouse Pro

Starter Android project inspired by the layout and concept in the provided GG Mouse Pro 3 screenshot. It uses native Java/Android views and has no third-party library dependencies.

## Included
- Dark Nebula-themed control center with Game, Mouse, Keyboard, and Settings tabs.
- List and launch installed apps/games.
- Mouse profile settings (sensitivity, invert-Y, enable profile).
- Editable keyboard mapping labels saved locally.
- Optional movable floating bubble (requires Android “Display over other apps” permission).

## Important limitation
This is a buildable starter project, not a full input-remapping engine. Android ordinary apps cannot freely inject mouse/keyboard input into arbitrary third-party games. True in-game mapping may require supported hardware, game-specific APIs, accessibility capabilities where appropriate, or privileged/system integration. This project does not bypass anti-cheat or Android security.

## Build APK in Android Studio
1. Install Android Studio and an Android SDK platform (API 35 or let Gradle install it).
2. Open this folder (`NebulaMousePro`) in Android Studio.
3. Wait for Gradle sync. Use JDK 17.
4. Connect an Android phone with USB debugging enabled, or create an emulator.
5. Click **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. The debug APK is usually created at `app/build/outputs/apk/debug/app-debug.apk`.
7. On your own device, install the APK and grant “Display over other apps” only if you want the floating bubble.

## Build from terminal
From the project root, with Android SDK and JDK 17 installed:
```bash
gradle assembleDebug
```
The output is normally `app/build/outputs/apk/debug/app-debug.apk`.

For a release APK, use **Build > Generate Signed Bundle / APK** in Android Studio and create a signing key. Keep that key private.
