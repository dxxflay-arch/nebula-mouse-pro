package com.nebula.mousepro;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    private final int bg = Color.rgb(12, 16, 35);
    private final int panel = Color.rgb(25, 32, 65);
    private final int accent = Color.rgb(95, 112, 255);
    private LinearLayout root, content, nav;
    private SharedPreferences prefs;
    private String page = "Game";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("nebula", MODE_PRIVATE);
        showPage("Game");
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }
    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setGravity(Gravity.CENTER_VERTICAL); return t;
    }
    private GradientDrawableCompat shape(int color, int radius) {
        return new GradientDrawableCompat(color, dp(radius));
    }
    private void showPage(String p) {
        page = p;
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(bg);
        setContentView(root);
        LinearLayout header = new LinearLayout(this); header.setOrientation(LinearLayout.VERTICAL);
        header.setPadding(dp(20), dp(28), dp(20), dp(18)); header.setBackgroundColor(bg);
        TextView brand = text("✦  NEBULA", 14, 0xff9da9ff, true);
        header.addView(brand);
        TextView title = text("Mouse Pro", 30, Color.WHITE, true); header.addView(title);
        TextView sub = text("CONTROL CENTER  •  v1.0", 11, 0xffaab2d5, false); header.addView(sub);
        root.addView(header);
        content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(18), dp(8), dp(18), dp(16));
        ScrollView scroll = new ScrollView(this); scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        nav = new LinearLayout(this); nav.setPadding(dp(6), dp(8), dp(6), dp(8)); nav.setBackgroundColor(0xff171d3b);
        String[] tabs = {"Game", "Mouse", "Keyboard", "Settings"};
        for (String tab : tabs) {
            Button b = new Button(this); b.setText(tab); b.setTextSize(11);
            b.setTextColor(tab.equals(page) ? Color.WHITE : 0xffaab2d5);
            b.setAllCaps(false); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(tab.equals(page) ? accent : 0xff171d3b));
            b.setPadding(0,0,0,0);
            b.setOnClickListener(v -> showPage(tab));
            nav.addView(b, new LinearLayout.LayoutParams(0, dp(48), 1));
        }
        root.addView(nav);
        if (p.equals("Game")) gamePage();
        else if (p.equals("Mouse")) mousePage();
        else if (p.equals("Keyboard")) keyboardPage();
        else settingsPage();
    }
    private void card(String title, String desc) {
        LinearLayout c = new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(16), dp(14), dp(16), dp(14)); c.setBackground(shape(panel, 18));
        TextView h = text(title, 16, Color.WHITE, true); c.addView(h);
        TextView d = text(desc, 12, 0xffb5bedf, false); d.setPadding(0, dp(6), 0, 0); c.addView(d);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = dp(12); content.addView(c, lp);
    }
    private void action(String label, Runnable r) {
        Button b = new Button(this); b.setText(label); b.setAllCaps(false); b.setTextColor(Color.WHITE);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(accent));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(48)); lp.bottomMargin = dp(10);
        content.addView(b, lp); b.setOnClickListener(v -> r.run());
    }
    private void gamePage() {
        card("Your games", "Launch a game installed on this device.");
        action("↻  Scan installed games", this::listGames);
        action("＋  Add game by package name", this::addGameByPackage);
        card("Quick note", "The launcher can open games. Key injection into third-party games is restricted by Android and may require game-specific support.");
    }
    private void listGames() {
        ArrayList<ApplicationInfo> apps = new ArrayList<>();
        PackageManager pm = getPackageManager();
        for (ApplicationInfo ai : pm.getInstalledApplications(PackageManager.GET_META_DATA)) {
            if (pm.getLaunchIntentForPackage(ai.packageName) != null && !ai.packageName.equals(getPackageName())) apps.add(ai);
        }
        Collections.sort(apps, (a,b) -> pm.getApplicationLabel(a).toString().compareToIgnoreCase(pm.getApplicationLabel(b).toString()));
        LinearLayout list = new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL);
        ScrollView sv = new ScrollView(this); sv.addView(list);
        for (ApplicationInfo ai : apps) {
            String name = pm.getApplicationLabel(ai).toString();
            Button item = new Button(this); item.setText(name + "\n" + ai.packageName); item.setAllCaps(false);
            item.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
            item.setBackgroundTintList(android.content.res.ColorStateList.valueOf(panel)); item.setTextColor(Color.WHITE);
            list.addView(item, new LinearLayout.LayoutParams(-1, dp(64)));
            item.setOnClickListener(v -> {
                Intent launch = pm.getLaunchIntentForPackage(ai.packageName);
                if (launch != null) startActivity(launch);
            });
        }
        new AlertDialog.Builder(this).setTitle("Installed apps").setView(sv).setNegativeButton("Close", null).show();
    }
    private void addGameByPackage() {
        EditText input = new EditText(this); input.setHint("e.g. com.example.game");
        new AlertDialog.Builder(this).setTitle("Open package").setView(input)
          .setPositiveButton("Open", (d,w) -> {
              String pkg = input.getText().toString().trim();
              Intent i = getPackageManager().getLaunchIntentForPackage(pkg);
              if (i != null) startActivity(i);
              else Toast.makeText(this, "App not found or cannot be launched", Toast.LENGTH_LONG).show();
          }).setNegativeButton("Cancel", null).show();
    }
    private void mousePage() {
        card("Mouse controls", "Configure a profile. These values are saved locally; actual in-game mouse translation depends on device and game support.");
        SeekBar sensitivity = new SeekBar(this); sensitivity.setMax(200);
        sensitivity.setProgress(prefs.getInt("sensitivity", 100));
        content.addView(text("Sensitivity: " + sensitivity.getProgress() + "%", 14, Color.WHITE, true));
        TextView val = (TextView) content.getChildAt(content.getChildCount()-1);
        sensitivity.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int n, boolean u) { val.setText("Sensitivity: " + n + "%"); prefs.edit().putInt("sensitivity", n).apply(); }
            public void onStartTrackingTouch(SeekBar s) {}
            public void onStopTrackingTouch(SeekBar s) {}
        });
        content.addView(sensitivity, new LinearLayout.LayoutParams(-1, dp(48)));
        switchRow("Invert Y axis", "invertY");
        switchRow("Enable mouse profile", "mouseEnabled");
        action("Show floating control", this::enableOverlay);
    }
    private void switchRow(String label, String key) {
        Switch s = new Switch(this); s.setText(label); s.setTextColor(Color.WHITE);
        s.setPadding(dp(4), dp(10), dp(4), dp(10)); s.setChecked(prefs.getBoolean(key, false));
        s.setOnCheckedChangeListener((b, checked) -> prefs.edit().putBoolean(key, checked).apply());
        content.addView(s, new LinearLayout.LayoutParams(-1, dp(54)));
    }
    private void keyboardPage() {
        card("Keyboard mapping", "Save preferred key labels for your profile. This starter app does not inject keys into other apps; Android generally prevents ordinary apps from doing that.");
        String[] names = {"Move forward", "Move backward", "Move left", "Move right", "Jump", "Action"};
        String[] keys = {"forward", "backward", "left", "right", "jump", "action"};
        for (int i=0;i<names.length;i++) {
            final String k = keys[i];
            LinearLayout row = new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL);
            TextView label = text(names[i], 14, Color.WHITE, false);
            row.addView(label, new LinearLayout.LayoutParams(0, dp(52), 1));
            EditText edit = new EditText(this); edit.setSingleLine(true); edit.setEms(4); edit.setTextSize(14);
            edit.setText(prefs.getString("key_"+k, new String[]{"W","S","A","D","SPACE","E"}[i]));
            edit.setTextColor(Color.WHITE); edit.setHintTextColor(0xffaab2d5); edit.setHint("Key");
            edit.setOnFocusChangeListener((v, focus) -> { if (!focus) prefs.edit().putString("key_"+k, edit.getText().toString().trim()).apply(); });
            row.addView(edit); content.addView(row);
        }
        action("Save keyboard profile", () -> {
            for (int i=0;i<content.getChildCount();i++) {
                View v = content.getChildAt(i);
                if (v instanceof LinearLayout) for (int j=0;j<((LinearLayout)v).getChildCount();j++) {
                    View c = ((LinearLayout)v).getChildAt(j);
                    if (c instanceof EditText) ((EditText)c).clearFocus();
                }
            }
            Toast.makeText(this, "Keyboard profile saved", Toast.LENGTH_SHORT).show();
        });
    }
    private void settingsPage() {
        card("App settings", "Nebula Mouse Pro • local profile");
        action("Request floating-window permission", this::enableOverlay);
        action("About / limitations", () -> new AlertDialog.Builder(this).setTitle("About Nebula Mouse Pro")
          .setMessage("This starter project includes a game launcher, mouse profile settings, key-label mapping, and an optional floating panel. It does not bypass Android security or anti-cheat protections.")
          .setPositiveButton("OK", null).show());
    }
    private void enableOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
            startActivity(i);
        } else {
            startService(new Intent(this, OverlayService.class));
            Toast.makeText(this, "Floating panel started", Toast.LENGTH_SHORT).show();
        }
    }
    static class GradientDrawableCompat extends android.graphics.drawable.GradientDrawable {
        GradientDrawableCompat(int color, float radius) { setColor(color); setCornerRadius(radius); }
    }
}
