package com.nebula.mousepro;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

public class OverlayService extends Service {
    private WindowManager wm;
    private TextView bubble;
    @Override public IBinder onBind(Intent intent) { return null; }
    @Override public void onCreate() {
        super.onCreate();
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return; }
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        bubble = new TextView(this);
        bubble.setText("✦ N");
        bubble.setTextColor(Color.WHITE); bubble.setTextSize(16); bubble.setTypeface(null, Typeface.BOLD);
        bubble.setGravity(Gravity.CENTER);
        bubble.setBackground(new android.graphics.drawable.GradientDrawable() {{
            setColor(0xff5f70ff); setCornerRadius(60);
        }});
        int type = android.os.Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(56,56,type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.END; lp.x = 24; lp.y = 180;
        try { wm.addView(bubble, lp); } catch (Exception e) { stopSelf(); return; }
        bubble.setOnClickListener(v -> Toast.makeText(this, "Nebula floating panel • profile controls are in the app", Toast.LENGTH_SHORT).show());
        bubble.setOnTouchListener(new android.view.View.OnTouchListener() {
            int startX, startY; float downX, downY;
            public boolean onTouch(android.view.View v, android.view.MotionEvent e) {
                if (e.getAction() == android.view.MotionEvent.ACTION_DOWN) {
                    startX=lp.x; startY=lp.y; downX=e.getRawX(); downY=e.getRawY(); return false;
                }
                if (e.getAction() == android.view.MotionEvent.ACTION_MOVE) {
                    lp.x=startX+(int)(downX-e.getRawX()); lp.y=startY+(int)(e.getRawY()-downY);
                    try { wm.updateViewLayout(bubble,lp); } catch(Exception ignored) {}
                    return true;
                }
                return false;
            }
        });
    }
    @Override public void onDestroy() {
        if (wm != null && bubble != null) try { wm.removeView(bubble); } catch(Exception ignored) {}
        super.onDestroy();
    }
}
